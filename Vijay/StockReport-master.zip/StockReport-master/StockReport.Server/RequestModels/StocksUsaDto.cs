﻿namespace StockReport.Server.RequestModels
{
    public class StocksUsaDto
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public string? Dayofweek { get; set; }
    }
}
